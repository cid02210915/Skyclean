from .cmb_data import CMB_Data
# print("hello from skyclean/CMB_data/__init__.py!")