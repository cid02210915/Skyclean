class CMB_data:
    pass