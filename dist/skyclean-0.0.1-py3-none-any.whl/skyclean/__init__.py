# from .CMB_data.CMB_data import CMB_data

from .CMB_data import CMB_data
