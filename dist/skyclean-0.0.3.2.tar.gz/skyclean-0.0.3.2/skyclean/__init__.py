from .CMB_data import CMB_Data

# print(type(CMB_Data()))


